function initializeSearchFormSubmit() {
//	    $(".search-form").submit(function(e) {
//		// e.preventDefault(); // 폼의 기본 동작 중단
//		// var searchQuery = $(this).find("input").val();
//		// $.ajax({
//		// url: "/ex/search", // 서버의 검색 처리 URL로 변경해야 함
//		// method: "GET",
//		// data: { query: searchQuery },
//		// success: function(response) {
//		// $(".content-container").html(response);
//		// },
//		// error: function() {
//		// alert("검색에 실패했습니다.");
//		// }
//		// });
//		var actionUrl = "/ex/search";
//
//		$(this).attr("action", actionUrl);
//	});
}