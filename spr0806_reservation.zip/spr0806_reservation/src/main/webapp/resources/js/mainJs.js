function toggleMenu() {
	var dropdownMenu = document.getElementById("dropdown-menu"); // 오타 수정 완료
	dropdownMenu.style.display = dropdownMenu.style.display === "block" ? "none"
			: "block";
}